#include <assert.h>
#include <stddef.h>
#include "../include/test_str.h"
#include "str.c"

void test_strlen() {
    const char s1[] = "\0";
    const char s2[] = "abcabc";
    assert(strlen(s1) == 0);
    assert(strlen(s2) == 6);
    return;
}

void test_strcat() {
    //assert();
    //assert();
    return;
}

void test_strcpy() {
    //assert();
    //assert();
    return;
}

void test_strcmp() {
    //assert(strcmp("abc"[0], "abcabc"[0]) < 0);
    //assert(strcmp("abc"[0], "abc"[0]) == 0);
    //assert(strcmp("abcabc"[0], "abc"[0]) > 0);
    return;
}

int main() {

    //test_strlen();
    //test_strcat();
    //test_strcpy();
    //test_strcmp();

    return 0;
}
