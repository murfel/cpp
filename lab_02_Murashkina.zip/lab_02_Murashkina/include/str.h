#include <stddef.h>

size_t strlen(const char * str);
char * strcat(char * to, const char * from);
char * strcpy(char * to, const char * from);
int strcmp(const char * str1, const char * str2);
