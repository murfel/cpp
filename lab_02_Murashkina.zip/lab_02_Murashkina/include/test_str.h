void test_strlen();
void test_strcat();
void test_strcpy();
void test_strcmp();
